package java.sql;

public class Connection {

	public Statement createStatement() {
		// TODO Auto-generated method stub
		return null;
	}

}
